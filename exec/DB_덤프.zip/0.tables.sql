create table book
(
    price_standard   int           null,
    pub_date         datetime(6)   null,
    series_id        bigint        null,
    isbn             varchar(13)   not null
        primary key,
    cover            varchar(2048) null,
    author           varchar(255)  null,
    publisher        varchar(255)  null,
    title            varchar(255)  null,
    book_description text          null
);

create table regcode
(
    id    bigint       not null
        primary key,
    dong  varchar(255) null,
    gungu varchar(255) null,
    si    varchar(255) null
);

create table series
(
    id   bigint       not null
        primary key,
    name varchar(255) null
);

create table users
(
    created_at   datetime(6)                                                                      null,
    deleted_at   datetime(6)                                                                      null,
    id           bigint auto_increment
        primary key,
    regcode_id   bigint                                                                           null,
    updated_at   datetime(6)                                                                      null,
    oauth        varchar(10)                                                                      null,
    password     varchar(300)                                                                     null,
    introduction varchar(600)                                                                     null,
    profile_url  varchar(3000) default 'https://polaris-bucket.s3.amazonaws.com/polaris_logo.png' null,
    email        varchar(255)                                                                     null,
    nickname     varchar(255)                                                                     null,
    constraint FK789ssfoq8smb8nspr0xb1luto
        foreign key (regcode_id) references regcode (id)
);

create table follow
(
    created_at        datetime(6) null,
    deleted_at        datetime(6) null,
    follower_user_id  bigint      null,
    following_user_id bigint      null,
    id                bigint auto_increment
        primary key,
    updated_at        datetime(6) null,
    constraint FK5591hwflkyq3kwiaij7h3wfes
        foreign key (follower_user_id) references users (id),
    constraint FKatlkvsyd2ipaq17txxs3wptw0
        foreign key (following_user_id) references users (id)
);

create table trade
(
    created_at  datetime(6)                      null,
    finished_at datetime(6)                      null,
    id          bigint auto_increment
        primary key,
    receiver_id bigint                           null,
    sender_id   bigint                           null,
    status      enum ('INPROGRESS', 'COMPLETED') null,
    trade_type  enum ('EXCHANGE', 'PURCHASE')    null,
    constraint FK4hsvam9r8thl27vqkdurn5vc6
        foreign key (sender_id) references users (id),
    constraint FKr7l3mae1clthk4k9crw5iiqfu
        foreign key (receiver_id) references users (id)
);

create table chat_message
(
    created_at datetime(6)            null,
    id         bigint auto_increment
        primary key,
    trade_id   bigint                 null,
    user_id    bigint                 null,
    message    varchar(3000)          null,
    type       enum ('TEXT', 'IMAGE') null,
    constraint FKd3oo2bhroe16913kh5pwtgk3h
        foreign key (user_id) references users (id),
    constraint FKlxhrwyt8mlvavyo5csfg79ov1
        foreign key (trade_id) references trade (id)
            on delete cascade
);

create table user_book
(
    is_opened             tinyint(1)   null,
    is_owned              tinyint(1)   null,
    price                 int          null,
    created_at            datetime(6)  null,
    deleted_at            datetime(6)  null,
    id                    bigint auto_increment
        primary key,
    updated_at            datetime(6)  null,
    user_id               bigint       null,
    book_isbn             varchar(13)  null,
    user_book_description varchar(600) null,
    user_book_trade_type  varchar(10)  null,
    constraint FKhon6i1tqj4tp43386dq6uo9ch
        foreign key (user_id) references users (id),
    constraint FKlcro2vgpieywr0gshy0koir2
        foreign key (book_isbn) references book (isbn)
);

create table essay
(
    hit          int default 0 not null,
    is_opened    bit           null,
    created_at   datetime(6)   null,
    deleted_at   datetime(6)   null,
    id           bigint auto_increment
        primary key,
    updated_at   datetime(6)   null,
    user_book_id bigint        null,
    user_id      bigint        null,
    title        varchar(255)  null,
    content      text          null,
    constraint FK78oq4fvuq36y7uimbob6bpeb1
        foreign key (user_book_id) references user_book (id),
    constraint FKiu0fap925fb39joanfg19dccv
        foreign key (user_id) references users (id)
);

create table comment
(
    created_at datetime(6)  null,
    deleted_at datetime(6)  null,
    essay_id   bigint       null,
    id         bigint auto_increment
        primary key,
    updated_at datetime(6)  null,
    user_id    bigint       null,
    content    varchar(600) null,
    constraint FK4y44h3k4tuwut28ihv5h2axjg
        foreign key (essay_id) references essay (id),
    constraint FKqm52p1v3o13hy268he0wcngr5
        foreign key (user_id) references users (id)
);

create table scrap
(
    is_deleted bit default b'0' null,
    essay_id   bigint           null,
    id         bigint auto_increment
        primary key,
    user_id    bigint           null,
    constraint FK6jcivlvmiwrx9hd1d7h2tkije
        foreign key (user_id) references users (id),
    constraint FK9ibwp4eqcw2rjpq7661q54ybc
        foreign key (essay_id) references essay (id)
);

create table trade_user_book
(
    id           int auto_increment
        primary key,
    trade_id     bigint null,
    user_book_id bigint null,
    constraint FK1fj2csts7vgmftgnt8t9cwtly
        foreign key (user_book_id) references user_book (id),
    constraint FK7i9ac01cb9om7xixlcv15t228
        foreign key (trade_id) references trade (id)
);

create index email_index
    on users (email);

create index nickname_index
    on users (nickname);

